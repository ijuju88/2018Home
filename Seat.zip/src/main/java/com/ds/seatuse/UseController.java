package com.ds.seatuse;

import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ds.seat.dao.SeatMemberDAO;
import com.ds.seat.dao.SeatShowDAO;
import com.ds.seat.dao.ShowPriceDAO;
import com.ds.seat.vo.Seat_Show;
import com.ds.seat.vo.Seat_Show_Price_List;


/**
 * Handles requests for the application home page.
 */
@Controller
public class UseController {

	@Autowired
	private SeatShowDAO ssDAO;
	
	@Autowired
	private ShowPriceDAO spDAO;

	//로그인후 관리자 메인페이지
	@RequestMapping(value = "homeshowone.do", method = RequestMethod.GET)
	public String adminindex(Model model,@RequestParam("show_no") Long show_no) {
		Seat_Show ssVO=ssDAO.selectSeatshow(show_no);
		Seat_Show_Price_List ssplVO=spDAO.selectPriceOne(show_no);
		
		model.addAttribute("ssVO",ssVO);
		model.addAttribute("ssplVO",ssplVO);
		
		return "use/homeshowone";
	}


	

}

