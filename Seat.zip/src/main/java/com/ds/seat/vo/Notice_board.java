package com.ds.seat.vo;

public class Notice_board {
	//http://devofhwb.tistory.com/17
}
